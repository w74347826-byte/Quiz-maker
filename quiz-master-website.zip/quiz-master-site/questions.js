window.QUIZ_QUESTIONS = {
  "General Knowledge": [
    [
      "What is the capital of Pakistan?",
      [
        "Lahore",
        "Islamabad",
        "Karachi",
        "Peshawar"
      ],
      1,
      "Islamabad is the capital of Pakistan."
    ],
    [
      "Which is the largest ocean?",
      [
        "Atlantic",
        "Indian",
        "Pacific",
        "Arctic"
      ],
      2,
      "The Pacific Ocean is the largest."
    ],
    [
      "How many continents are there?",
      [
        "5",
        "6",
        "7",
        "8"
      ],
      2,
      "There are seven continents."
    ],
    [
      "Which planet do we live on?",
      [
        "Mars",
        "Earth",
        "Venus",
        "Jupiter"
      ],
      1,
      "Earth is our home planet."
    ],
    [
      "What is the currency of Japan?",
      [
        "Yuan",
        "Won",
        "Yen",
        "Rupee"
      ],
      2,
      "Japan uses the yen."
    ],
    [
      "Which animal is known as the king of the jungle?",
      [
        "Tiger",
        "Elephant",
        "Lion",
        "Leopard"
      ],
      2,
      "The lion is commonly called the king of the jungle."
    ],
    [
      "How many days are in a leap year?",
      [
        "364",
        "365",
        "366",
        "367"
      ],
      2,
      "A leap year has 366 days."
    ],
    [
      "What is the national language of Pakistan?",
      [
        "Punjabi",
        "Urdu",
        "Sindhi",
        "English"
      ],
      1,
      "Urdu is Pakistan's national language."
    ],
    [
      "Which is the smallest continent?",
      [
        "Europe",
        "Australia",
        "South America",
        "Antarctica"
      ],
      1,
      "Australia is the smallest continent."
    ],
    [
      "How many colors are in a rainbow traditionally?",
      [
        "5",
        "6",
        "7",
        "8"
      ],
      2,
      "A rainbow is traditionally described as having seven colors."
    ],
    [
      "Which bird is a symbol of peace?",
      [
        "Eagle",
        "Dove",
        "Crow",
        "Parrot"
      ],
      1,
      "The dove is widely used as a symbol of peace."
    ],
    [
      "What is the opposite of north?",
      [
        "East",
        "West",
        "South",
        "Left"
      ],
      2,
      "South is opposite north."
    ],
    [
      "Which month has 28 days in a common year?",
      [
        "February",
        "April",
        "All months",
        "June"
      ],
      0,
      "February has 28 days in a common year."
    ],
    [
      "How many hours are in one day?",
      [
        "12",
        "18",
        "24",
        "36"
      ],
      2,
      "One day has 24 hours."
    ],
    [
      "Which is the largest land animal?",
      [
        "Giraffe",
        "African elephant",
        "Rhino",
        "Hippo"
      ],
      1,
      "The African elephant is the largest land animal."
    ]
  ],
  "Science": [
    [
      "What is the chemical formula for water?",
      [
        "CO2",
        "O2",
        "H2O",
        "NaCl"
      ],
      2,
      "Water is H2O."
    ],
    [
      "Which planet is called the Red Planet?",
      [
        "Venus",
        "Mars",
        "Mercury",
        "Saturn"
      ],
      1,
      "Iron-rich dust makes Mars look red."
    ],
    [
      "Which gas do plants absorb?",
      [
        "Oxygen",
        "Carbon dioxide",
        "Helium",
        "Hydrogen"
      ],
      1,
      "Plants use carbon dioxide during photosynthesis."
    ],
    [
      "What is the center of an atom called?",
      [
        "Cell",
        "Nucleus",
        "Core shell",
        "Electron"
      ],
      1,
      "An atom's center is its nucleus."
    ],
    [
      "Which organ pumps blood?",
      [
        "Lungs",
        "Brain",
        "Heart",
        "Liver"
      ],
      2,
      "The heart pumps blood around the body."
    ],
    [
      "What force pulls objects toward Earth?",
      [
        "Friction",
        "Gravity",
        "Magnetism",
        "Pressure"
      ],
      1,
      "Gravity attracts objects toward Earth."
    ],
    [
      "How many legs does an insect have?",
      [
        "4",
        "6",
        "8",
        "10"
      ],
      1,
      "Insects have six legs."
    ],
    [
      "Which part of a plant absorbs water?",
      [
        "Flower",
        "Leaves",
        "Roots",
        "Fruit"
      ],
      2,
      "Roots absorb water from the soil."
    ],
    [
      "What is the boiling point of water at sea level?",
      [
        "50°C",
        "75°C",
        "100°C",
        "150°C"
      ],
      2,
      "Water boils at about 100°C at sea level."
    ],
    [
      "Which vitamin can sunlight help the body produce?",
      [
        "Vitamin A",
        "Vitamin B12",
        "Vitamin C",
        "Vitamin D"
      ],
      3,
      "Sunlight helps the body produce vitamin D."
    ],
    [
      "Which gas do humans need to breathe?",
      [
        "Oxygen",
        "Carbon dioxide",
        "Neon",
        "Methane"
      ],
      0,
      "Humans need oxygen for respiration."
    ],
    [
      "What is Earth's natural satellite?",
      [
        "Sun",
        "Moon",
        "Mars",
        "Venus"
      ],
      1,
      "The Moon is Earth's natural satellite."
    ],
    [
      "Which state of matter has a fixed shape?",
      [
        "Gas",
        "Liquid",
        "Solid",
        "Vapor"
      ],
      2,
      "Solids generally have a fixed shape."
    ],
    [
      "What do bees collect from flowers?",
      [
        "Sand",
        "Nectar",
        "Leaves",
        "Dew only"
      ],
      1,
      "Bees collect nectar from flowers."
    ],
    [
      "Which instrument measures temperature?",
      [
        "Barometer",
        "Thermometer",
        "Compass",
        "Ruler"
      ],
      1,
      "A thermometer measures temperature."
    ]
  ],
  "Mathematics": [
    [
      "What is 12 × 8?",
      [
        "86",
        "96",
        "108",
        "88"
      ],
      1,
      "12 multiplied by 8 equals 96."
    ],
    [
      "What is 144 ÷ 12?",
      [
        "10",
        "11",
        "12",
        "14"
      ],
      2,
      "144 divided by 12 equals 12."
    ],
    [
      "What is 15 + 27?",
      [
        "32",
        "42",
        "52",
        "41"
      ],
      1,
      "15 plus 27 equals 42."
    ],
    [
      "What is 9 squared?",
      [
        "18",
        "72",
        "81",
        "99"
      ],
      2,
      "9 × 9 equals 81."
    ],
    [
      "How many degrees are in a right angle?",
      [
        "45°",
        "90°",
        "180°",
        "360°"
      ],
      1,
      "A right angle measures 90 degrees."
    ],
    [
      "What is half of 250?",
      [
        "100",
        "115",
        "125",
        "150"
      ],
      2,
      "250 divided by 2 is 125."
    ],
    [
      "What is 7 × 6?",
      [
        "36",
        "40",
        "42",
        "48"
      ],
      2,
      "7 times 6 equals 42."
    ],
    [
      "Which is an even number?",
      [
        "13",
        "17",
        "22",
        "29"
      ],
      2,
      "22 is divisible by 2."
    ],
    [
      "What is 100 minus 38?",
      [
        "62",
        "68",
        "72",
        "58"
      ],
      0,
      "100 − 38 = 62."
    ],
    [
      "What is the perimeter of a square with side 5 cm?",
      [
        "10 cm",
        "15 cm",
        "20 cm",
        "25 cm"
      ],
      2,
      "Perimeter is 4 × side, so 20 cm."
    ],
    [
      "What is 3/4 as a percentage?",
      [
        "25%",
        "50%",
        "75%",
        "80%"
      ],
      2,
      "Three quarters equals 75%."
    ],
    [
      "What is the next number: 2, 4, 6, 8, ...?",
      [
        "9",
        "10",
        "12",
        "14"
      ],
      1,
      "The sequence increases by 2."
    ],
    [
      "What is 5 cubed?",
      [
        "15",
        "25",
        "75",
        "125"
      ],
      3,
      "5 × 5 × 5 = 125."
    ],
    [
      "How many sides does a hexagon have?",
      [
        "5",
        "6",
        "7",
        "8"
      ],
      1,
      "A hexagon has six sides."
    ],
    [
      "What is 20% of 100?",
      [
        "10",
        "15",
        "20",
        "25"
      ],
      2,
      "20% of 100 is 20."
    ]
  ],
  "History": [
    [
      "Who is known as the founder of Pakistan?",
      [
        "Allama Iqbal",
        "Quaid-e-Azam Muhammad Ali Jinnah",
        "Liaquat Ali Khan",
        "Sir Syed Ahmad Khan"
      ],
      1,
      "Muhammad Ali Jinnah led the Pakistan Movement."
    ],
    [
      "In which year did Pakistan become independent?",
      [
        "1940",
        "1945",
        "1947",
        "1956"
      ],
      2,
      "Pakistan became independent in 1947."
    ],
    [
      "Who was the first Governor-General of Pakistan?",
      [
        "Liaquat Ali Khan",
        "Ayub Khan",
        "Muhammad Ali Jinnah",
        "Iskander Mirza"
      ],
      2,
      "Muhammad Ali Jinnah was the first Governor-General."
    ],
    [
      "Which ancient civilization built the pyramids at Giza?",
      [
        "Romans",
        "Egyptians",
        "Greeks",
        "Persians"
      ],
      1,
      "The pyramids at Giza were built by ancient Egyptians."
    ],
    [
      "Who wrote the Pakistan Resolution text as presented in 1940?",
      [
        "A.K. Fazlul Huq presented it",
        "Mahatma Gandhi",
        "Jawaharlal Nehru",
        "Winston Churchill"
      ],
      0,
      "A.K. Fazlul Huq moved the Lahore Resolution."
    ],
    [
      "Where was the Lahore Resolution adopted?",
      [
        "Karachi",
        "Lahore",
        "Delhi",
        "Dhaka"
      ],
      1,
      "It was adopted in Lahore in 1940."
    ],
    [
      "Which wall divided Berlin during the Cold War?",
      [
        "Great Wall",
        "Berlin Wall",
        "Hadrian's Wall",
        "Western Wall"
      ],
      1,
      "The Berlin Wall divided East and West Berlin."
    ],
    [
      "Who was the first person to walk on the Moon?",
      [
        "Yuri Gagarin",
        "Neil Armstrong",
        "Buzz Aldrin",
        "John Glenn"
      ],
      1,
      "Neil Armstrong walked on the Moon in 1969."
    ],
    [
      "Which empire was ruled by Julius Caesar?",
      [
        "Ottoman",
        "Roman",
        "Mongol",
        "Mughal"
      ],
      1,
      "Julius Caesar was a Roman leader."
    ],
    [
      "In which year did World War II end?",
      [
        "1942",
        "1944",
        "1945",
        "1950"
      ],
      2,
      "World War II ended in 1945."
    ],
    [
      "Who was the poet-philosopher associated with the idea of Pakistan?",
      [
        "Faiz Ahmed Faiz",
        "Allama Iqbal",
        "Mir Taqi Mir",
        "Hafeez Jalandhari"
      ],
      1,
      "Allama Iqbal proposed the idea of a separate Muslim state in his 1930 address."
    ],
    [
      "Which city was the capital of the Mughal Empire for much of Akbar's reign?",
      [
        "Fatehpur Sikri",
        "London",
        "Istanbul",
        "Cairo"
      ],
      0,
      "Akbar made Fatehpur Sikri his capital for a period."
    ],
    [
      "Who was the first female Prime Minister of Pakistan?",
      [
        "Fatima Jinnah",
        "Benazir Bhutto",
        "Hina Rabbani Khar",
        "Maryam Jinnah"
      ],
      1,
      "Benazir Bhutto became Prime Minister in 1988."
    ],
    [
      "The ancient Olympic Games began in which country?",
      [
        "Italy",
        "Greece",
        "Egypt",
        "China"
      ],
      1,
      "The ancient Olympic Games began in Greece."
    ],
    [
      "Which movement led to India's independence in 1947?",
      [
        "Industrial Revolution",
        "Indian independence movement",
        "Renaissance",
        "Reformation"
      ],
      1,
      "The Indian independence movement led to the end of British rule."
    ]
  ],
  "English": [
    [
      "Which word is a synonym of happy?",
      [
        "Angry",
        "Joyful",
        "Tired",
        "Afraid"
      ],
      1,
      "Joyful means happy."
    ],
    [
      "What is the past tense of go?",
      [
        "Goed",
        "Gone",
        "Went",
        "Going"
      ],
      2,
      "The past tense of go is went."
    ],
    [
      "Which word is a noun?",
      [
        "Quickly",
        "Beautiful",
        "Teacher",
        "Run"
      ],
      2,
      "Teacher names a person, so it is a noun."
    ],
    [
      "Choose the correct spelling.",
      [
        "Beautifull",
        "Beautiful",
        "Beutiful",
        "Beautifal"
      ],
      1,
      "Beautiful is the correct spelling."
    ],
    [
      "What is the opposite of ancient?",
      [
        "Old",
        "Historic",
        "Modern",
        "Past"
      ],
      2,
      "Modern is the opposite of ancient."
    ],
    [
      "Which article fits: ___ apple?",
      [
        "A",
        "An",
        "Thee",
        "No article ever"
      ],
      1,
      "Use 'an' before a vowel sound."
    ],
    [
      "What is the plural of child?",
      [
        "Childs",
        "Childes",
        "Children",
        "Childrens"
      ],
      2,
      "The plural of child is children."
    ],
    [
      "Which punctuation ends a question?",
      [
        "Full stop",
        "Comma",
        "Question mark",
        "Colon"
      ],
      2,
      "A question ends with a question mark."
    ],
    [
      "Choose the adjective.",
      [
        "Softly",
        "Soft",
        "Soften",
        "Softness"
      ],
      1,
      "Soft describes a noun, so it is an adjective."
    ],
    [
      "What is the opposite of generous?",
      [
        "Kind",
        "Giving",
        "Selfish",
        "Helpful"
      ],
      2,
      "Selfish is an opposite of generous."
    ],
    [
      "Which sentence is correct?",
      [
        "She go to school.",
        "She goes to school.",
        "She going school.",
        "She gone school."
      ],
      1,
      "With she, use 'goes' in the simple present."
    ],
    [
      "What is a synonym for begin?",
      [
        "Finish",
        "Start",
        "Stop",
        "Close"
      ],
      1,
      "Start means begin."
    ],
    [
      "Which is a pronoun?",
      [
        "Garden",
        "They",
        "Green",
        "Jump"
      ],
      1,
      "They is a pronoun."
    ],
    [
      "What is the comparative of tall?",
      [
        "Tallest",
        "More tall",
        "Taller",
        "Tally"
      ],
      2,
      "The comparative form is taller."
    ],
    [
      "Which word is an adverb?",
      [
        "Careful",
        "Carefully",
        "Care",
        "Caring"
      ],
      1,
      "Carefully describes how an action is done."
    ]
  ],
  "Computer Science": [
    [
      "What does CPU stand for?",
      [
        "Central Processing Unit",
        "Computer Power Utility",
        "Core Program Unit",
        "Central Print Unit"
      ],
      0,
      "CPU means Central Processing Unit."
    ],
    [
      "Which language structures web pages?",
      [
        "HTML",
        "SQL",
        "Python only",
        "C++"
      ],
      0,
      "HTML structures webpage content."
    ],
    [
      "What does CSS control?",
      [
        "Webpage styling",
        "Computer power",
        "Internet speed",
        "Database storage"
      ],
      0,
      "CSS controls layout and visual styling."
    ],
    [
      "Which one is an operating system?",
      [
        "Windows",
        "Google",
        "HTML",
        "Wi-Fi"
      ],
      0,
      "Windows is an operating system."
    ],
    [
      "What does URL identify?",
      [
        "A web address",
        "A keyboard key",
        "A file type only",
        "A processor"
      ],
      0,
      "URL is the address of a resource on the web."
    ],
    [
      "Which device is used to point and click?",
      [
        "Monitor",
        "Mouse",
        "Speaker",
        "Printer"
      ],
      1,
      "A mouse is a pointing device."
    ],
    [
      "What is phishing?",
      [
        "A security scam",
        "A programming language",
        "A screen type",
        "A backup method"
      ],
      0,
      "Phishing tricks people into sharing sensitive information."
    ],
    [
      "Which is a common spreadsheet program?",
      [
        "Excel",
        "Paint",
        "Notepad",
        "VLC"
      ],
      0,
      "Microsoft Excel is spreadsheet software."
    ],
    [
      "What does RAM provide?",
      [
        "Temporary working memory",
        "Permanent paper storage",
        "Internet access",
        "Power supply"
      ],
      0,
      "RAM temporarily stores data in use."
    ],
    [
      "Which symbol often starts a hashtag?",
      [
        "@",
        "#",
        "&",
        "%"
      ],
      1,
      "A hashtag begins with #."
    ],
    [
      "What is a strong password practice?",
      [
        "Use 123456",
        "Reuse every password",
        "Use a unique long password",
        "Share it with friends"
      ],
      2,
      "Long, unique passwords improve account security."
    ],
    [
      "What does AI stand for?",
      [
        "Artificial Intelligence",
        "Automatic Internet",
        "Advanced Input",
        "Applied Information"
      ],
      0,
      "AI means Artificial Intelligence."
    ],
    [
      "Which is an example of a web browser?",
      [
        "Chrome",
        "Linux",
        "Excel",
        "Bluetooth"
      ],
      0,
      "Chrome is a web browser."
    ],
    [
      "What does a database store?",
      [
        "Organized information",
        "Only pictures",
        "Electricity",
        "Screen brightness"
      ],
      0,
      "Databases store and organize information."
    ],
    [
      "What is debugging?",
      [
        "Finding and fixing code errors",
        "Decorating a computer",
        "Deleting all files",
        "Installing a screen"
      ],
      0,
      "Debugging is finding and fixing software errors."
    ]
  ],
  "Business & Finance": [
    [
      "What is profit?",
      [
        "Revenue minus costs",
        "All expenses",
        "A loan only",
        "Employee hours"
      ],
      0,
      "Profit is what remains when costs are subtracted from revenue."
    ],
    [
      "What is a budget?",
      [
        "A plan for income and spending",
        "A bank card",
        "A tax receipt",
        "A sales logo"
      ],
      0,
      "A budget plans how money will be received and spent."
    ],
    [
      "What does ROI stand for?",
      [
        "Return on Investment",
        "Rate of Income",
        "Record of Inventory",
        "Risk of Interest"
      ],
      0,
      "ROI measures return relative to an investment's cost."
    ],
    [
      "Which is an asset?",
      [
        "Cash owned by a business",
        "Unpaid bill",
        "Loan owed",
        "Rent expense"
      ],
      0,
      "Cash owned by a business is an asset."
    ],
    [
      "What is marketing mainly about?",
      [
        "Understanding and serving customers",
        "Only counting cash",
        "Repairing computers",
        "Writing laws"
      ],
      0,
      "Marketing helps identify and satisfy customer needs."
    ],
    [
      "What is revenue?",
      [
        "Income from sales or services",
        "Only profit",
        "A business loan",
        "An unpaid expense"
      ],
      0,
      "Revenue is income earned from normal business activities."
    ],
    [
      "What is a customer?",
      [
        "Someone who buys goods or services",
        "Only a manager",
        "A tax form",
        "A supplier's building"
      ],
      0,
      "Customers purchase goods or services."
    ],
    [
      "What does a bank account help you do?",
      [
        "Keep and manage money",
        "Guarantee profit",
        "Remove all risk",
        "Avoid all expenses"
      ],
      0,
      "Bank accounts help people store and manage money."
    ],
    [
      "What is entrepreneurship?",
      [
        "Starting and running a business",
        "Only working for government",
        "Avoiding decisions",
        "Only buying products"
      ],
      0,
      "Entrepreneurs start and manage ventures."
    ],
    [
      "What is a liability?",
      [
        "An amount a business owes",
        "A product sold",
        "Cash received",
        "Owner's skill"
      ],
      0,
      "Liabilities are obligations or debts."
    ],
    [
      "Why do businesses keep records?",
      [
        "To track transactions and performance",
        "To make products heavier",
        "To avoid customers",
        "To remove competition"
      ],
      0,
      "Records help track finances and make decisions."
    ],
    [
      "What is supply?",
      [
        "Amount sellers offer for sale",
        "Amount buyers want only",
        "A business tax",
        "A profit percentage"
      ],
      0,
      "Supply is the amount sellers are willing to offer."
    ],
    [
      "What is demand?",
      [
        "Buyers' willingness and ability to buy",
        "Only goods in a warehouse",
        "Business debt",
        "Staff training"
      ],
      0,
      "Demand describes how much buyers want and can purchase."
    ],
    [
      "What is customer service?",
      [
        "Helping customers before and after purchase",
        "Only advertising",
        "Counting stock only",
        "Setting tax rates"
      ],
      0,
      "Customer service supports customers and solves problems."
    ],
    [
      "What is saving?",
      [
        "Keeping some money for future use",
        "Spending everything",
        "Borrowing more",
        "Paying a fine"
      ],
      0,
      "Saving means setting money aside for later."
    ]
  ],
  "Sports": [
    [
      "How many players from one team start on a football field?",
      [
        "9",
        "10",
        "11",
        "12"
      ],
      2,
      "A standard football team has 11 players on the field."
    ],
    [
      "Which sport uses a racket and shuttlecock?",
      [
        "Tennis",
        "Badminton",
        "Hockey",
        "Cricket"
      ],
      1,
      "Badminton is played with a racket and shuttlecock."
    ],
    [
      "How many rings are on the Olympic symbol?",
      [
        "4",
        "5",
        "6",
        "7"
      ],
      1,
      "The Olympic symbol has five rings."
    ],
    [
      "Which sport uses a bat, ball, and wickets?",
      [
        "Cricket",
        "Basketball",
        "Volleyball",
        "Swimming"
      ],
      0,
      "Cricket uses a bat, ball, and wickets."
    ],
    [
      "In which sport is a slam dunk scored?",
      [
        "Football",
        "Basketball",
        "Golf",
        "Rugby"
      ],
      1,
      "A slam dunk is a basketball shot."
    ],
    [
      "How many points is a free throw worth in basketball?",
      [
        "1",
        "2",
        "3",
        "4"
      ],
      0,
      "A successful free throw scores one point."
    ],
    [
      "Which sport is played at Wimbledon?",
      [
        "Tennis",
        "Cricket",
        "Boxing",
        "Hockey"
      ],
      0,
      "Wimbledon is a major tennis tournament."
    ],
    [
      "What is the length of a marathon approximately?",
      [
        "10 km",
        "21.1 km",
        "42.195 km",
        "50 km"
      ],
      2,
      "A marathon is 42.195 kilometres."
    ],
    [
      "Which sport includes a goalkeeper and penalty kicks?",
      [
        "Football",
        "Table tennis",
        "Badminton",
        "Athletics"
      ],
      0,
      "Football includes goalkeepers and penalty kicks."
    ],
    [
      "What equipment is essential for cycling?",
      [
        "Bicycle",
        "Bat",
        "Racket",
        "Gloves only"
      ],
      0,
      "Cycling is done on a bicycle."
    ],
    [
      "Which country is associated with sumo wrestling?",
      [
        "Japan",
        "Brazil",
        "Canada",
        "Egypt"
      ],
      0,
      "Sumo is a traditional Japanese wrestling sport."
    ],
    [
      "In tennis, what score comes after 30?",
      [
        "35",
        "40",
        "45",
        "50"
      ],
      1,
      "The usual point sequence is 0, 15, 30, 40."
    ],
    [
      "Which sport uses a puck?",
      [
        "Ice hockey",
        "Cricket",
        "Golf",
        "Baseball"
      ],
      0,
      "Ice hockey is played with a puck."
    ],
    [
      "How many players are on court for one volleyball team?",
      [
        "5",
        "6",
        "7",
        "8"
      ],
      1,
      "Indoor volleyball teams have six players on court."
    ],
    [
      "What is the person who enforces rules in a game called?",
      [
        "Spectator",
        "Referee",
        "Captain only",
        "Coach only"
      ],
      1,
      "A referee enforces the rules of a match."
    ]
  ]
};
