# Quiz Master Website

## Files
- `index.html`: Home page
- `categories.html`: eight quiz categories
- `quiz.html`: interactive MCQ quiz, difficulty selection, optional timer, text-to-speech, instant feedback, results and explanations
- `leaderboard.html`: scores stored in this browser
- `profile.html`: local quiz history and progress
- `about.html`, `contact.html`: information and contact form demo
- `style.css`: responsive purple-and-white theme
- `questions.js`: 120 questions (15 in each category)
- `script.js`: website and quiz functionality

## Run locally
Open `index.html` in a browser. For best results use a local server, such as VS Code Live Server.

## Publish on GitHub Pages
1. Unzip this folder.
2. Upload all files in this folder to the root of your GitHub repository (not the ZIP itself).
3. Keep file names exactly as shown.
4. In GitHub, open Settings → Pages and choose the branch/folder where these files are stored.
5. Wait for deployment, then refresh your site.

## Important limitations
This is a frontend-only version. Scores and profile history are stored in the current browser using localStorage, so they do not sync between devices or players. The contact form shows a demo confirmation and does not send email. GitHub Pages cannot run Python/Flask itself; a Python backend must be hosted separately and configured with its API URL.
